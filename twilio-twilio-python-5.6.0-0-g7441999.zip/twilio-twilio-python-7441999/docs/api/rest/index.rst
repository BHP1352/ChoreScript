===================================
:mod:`twilio`
===================================

.. module:: twilio

.. autoclass:: TwilioRestException
   :members:
   :inherited-members:

.. module:: twilio.rest

==============================
:mod:`twilio.rest`
==============================

.. autoclass:: TwilioRestClient
   :members:
   :inherited-members:

.. autoclass:: TwilioTaskRouterClient
   :members:
   :inherited-members:
